﻿truncate table TrackInstance
truncate table TrackActivity
truncate table TrackBookmark 
truncate table TrackCustom
 