truncate table Lead
delete System.Activities.DurableInstancing.InstancesTable