delete [System.Activities.DurableInstancing].InstancesTable
delete Assignment
delete Lead 