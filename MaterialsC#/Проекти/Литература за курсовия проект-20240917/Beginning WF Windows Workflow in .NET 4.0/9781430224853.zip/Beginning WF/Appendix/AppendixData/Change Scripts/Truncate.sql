delete [System.Activities.DurableInstancing].KeysTable
delete [System.Activities.DurableInstancing].InstancesTable

truncate table QueueTrack
truncate table Request
truncate table QueueInstance
