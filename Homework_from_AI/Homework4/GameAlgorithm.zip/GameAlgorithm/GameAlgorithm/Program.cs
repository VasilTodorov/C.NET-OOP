﻿namespace GameAlgorithm
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            SeaChess.Game();
            
        }
    }
}
