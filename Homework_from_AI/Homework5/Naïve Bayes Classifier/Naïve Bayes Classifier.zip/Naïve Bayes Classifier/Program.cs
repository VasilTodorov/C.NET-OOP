﻿namespace Naïve_Bayes_Classifier
{
    internal class Program
    {
        static void Main(string[] args)
        {
            NaiveBayesClassifier a = new NaiveBayesClassifier("house-votes-84.data");
            //myDictionary.cou
        }
    }
}
