﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Naïve_Bayes_Classifier
{
    struct Info
    {
        public string Class;
        public string[] Results;

        public Info(string[] data)
        {
            Class = data[0];
            Results = new string[data.Length - 1];
            for (int i = 1; i < data.Length; i++)
                Results[i - 1] = data[i];
        }
    }
    public class NaiveBayesClassifier
    {
        const int LAMBDA = 1;
        Dictionary<string, double> priorProbabilities;
        Dictionary<int, Dictionary<string, double>> conditionalProbabilities;
        //string pro
        private Info[] processData(string trainData)
        {
            List<Info> data = new List<Info>();
            //string name = "uk12_xy.csv";
            string path = @"C:\Users\Vasil\source\repos\C#OOP\Homework_from_AI\Homework5\Naïve Bayes Classifier\congressional+voting+records\" + trainData;
            if (File.Exists(path))
            {
                //Console.WriteLine("Exists");               
                string line;

                // Read the file and display it line by line.
                System.IO.StreamReader file = new System.IO.StreamReader(path);

                while ((line = file.ReadLine()!) != null)
                {
                    data.Add(new Info(line.Split(",")));                 
                }

                file.Close();
            }

            return data.ToArray();
        }
        public void trainNaiveBayes(string trainData)
        {

            // Initialize variables
            Dictionary<string, int> countClass = new Dictionary<string, int>();  //Count of occurrences for each class
            Dictionary<string, Dictionary<int, int>> CountResultGivenClass = new Dictionary<string, Dictionary<int, int>>();  // Count of occurrences for each word given each class
                                                                                                                              // int totalExamples = 0;  // Total number of training examples
            Info[] processedTrainData = processData(trainData);
            int numberOfExamples = processedTrainData.Length;
            // Process each training example
            foreach (var example in processedTrainData)
            {
                string classLabel = example.Class;
                if (!countClass.ContainsKey(classLabel))
                    countClass[classLabel] = 0;

                countClass[classLabel] += 1;  // Increment class count

                var info = example.Results;

                // Increment count for word given class


                for (int i = 0; i < info.Length; i++)
                {
                    if (!CountResultGivenClass[classLabel].ContainsKey(i))
                        CountResultGivenClass[classLabel][i] = 0;
                    if (info[i] == "y")
                        CountResultGivenClass[classLabel][i] += 1;
                }

            }

            //Calculate prior probabilities and conditional probabilities
            priorProbabilities = new Dictionary<string, double>();
            conditionalProbabilities = new Dictionary<int, Dictionary<string, double>>();
            int K = countClass.Count;
            int A = 3;

            foreach (var example in processedTrainData)
            {
                string classLabel = example.Class;
                priorProbabilities[classLabel] = (double)(countClass[classLabel]+LAMBDA) / (numberOfExamples + K * LAMBDA);

                var info = example.Results;                

                for (int i = 0; i < info.Length; i++)
                {
                    conditionalProbabilities[i][classLabel] = (double)(CountResultGivenClass[classLabel][i] + LAMBDA) / (countClass[classLabel] + LAMBDA * A);
                }
            }              
                
        }

        public NaiveBayesClassifier(string data)
        {
            trainNaiveBayes(data);
            foreach(var word in priorProbabilities)
                Console.WriteLine(word);
        }
    }
}
